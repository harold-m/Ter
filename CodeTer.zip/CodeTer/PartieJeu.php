<?php 

class Lapartie{
    public int $par;

    public function arreterJeu() {
// Ici nous définirons la fonction qui permettra d'arrêter le jeu
    }

    public function plusCourtChemin(){
        //plus court chemin nous permettant de definir le PAR minimum
        
    }
}

?>>