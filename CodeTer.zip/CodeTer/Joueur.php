<?php

declare(strict_types=1);
class Joueur{
   // public int $nombreJoueur;

    public String $nom;

    public function __construct(String $name){
        $this->nom=$name;
    }

    public function getNom(): String {
        return $this->$nom;
    }

  /*  public function setNom(String $nom): void {
        $this->$nom;

    }*/
 

    public function gainDuJoueur() : float {

    }

}
//$joueur2 = new Joueur('Harold');
//var_dump($joueur2);






?>


