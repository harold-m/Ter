<?php 
 require 'Joueur.php';
 

 $joueur1 = new Joueur('Harold');

 var_dump($joueur1);




?>