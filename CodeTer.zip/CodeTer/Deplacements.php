<?php 

class Deplacements {

   public function direction(){
       
   }

}


?>