<?php 

include Cases.php;

class Rouge extends Cases {

}


?>