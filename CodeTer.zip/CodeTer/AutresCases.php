<?php 

include Cases.php;

class Autre extends Cases {

}


?>